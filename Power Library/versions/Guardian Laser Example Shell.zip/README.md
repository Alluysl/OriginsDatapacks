# Guardian Laser Example Shell

[![License: CC0 1.0](https://img.shields.io/badge/License-CC0%201.0-lightgrey.svg)](https://creativecommons.org/publicdomain/zero/1.0/)

A datapack demonstrating the Guardian Laser power by giving it an origin. Note that here the Guardian Laser power requires the [corresponding datapack](https://github.com/Alluysl/OriginsDatapacks/tree/master/Power%20Library/src/Guardian%20Laser) to be present alongside it, but [it could have been integrated into this pack](https://github.com/Alluysl/OriginsDatapacks/tree/master/Power%20Library/src/Guardian%20Laser%20Example).

You may want to remove the license file if you use this as a template.