# 1.0.1

- Fixed a bug where throwing a trident while flying would make it go haywire, and opening chests and picking up items were difficult during flight (thanks [Inkbat](https://www.youtube.com/c/InkBat) for providing the solution in her [Storm Chaser video](https://youtu.be/ZFTL4bnsM6Q?t=217))
- As a consequence of fixing that bug, taking damage in flight no longer knocks you back greatly (if you wish to have this manually reimplemented, tell me)
- Added a mention in the "tiny" power's description that picking items up might still not be as fluid as it would be on a normal origin due to your small size


# 1.0.0

- Release